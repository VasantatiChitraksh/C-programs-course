#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
  	int n;
  	printf("Enter the no of numbers in the array:");
  	scanf("%d", &n);
  	int a[n];
  	srand(time(0));
  	for(int i=0;i<n;i++) {
  	a[i]=rand() % 5 + 1;
  	}
  	for(int i=0;i<n;i++) {
  	printf("%d " ,a[i]);
  	}
  	printf("\n");
  	int count[6];
  	for(int i=0;i<n;i++) {
  	count[a[i]]++ ;
  	}
  	for(int i=1;i<6;i++) {
  	printf("Count of %d:%d ",i,count[i]);
  	printf("\n");
  	}
  	return 0;
  	}
  	
