a=35;
b=34;
print(a+b)
