#include <stdio.h>
int main() {
for(int i=0;i<=10;i++) {
printf("The square and cube of %d are %d and %d\n", i,i*i,i*i*i);
}
return 0;
} 
