#include <stdio.h>
int main () { int n=5,f,i;
int k;
	for(i=1;i<=n;i++) { k=i;
	f=1;
	f=f*k;
	k==0;
	f=f; 
	}
	printf("%d", f);
	return 0;
	}
