#include <stdio.h>
int main () { float x;
x=(5+4*(3-2)/3*3)%3;
printf("%f", x);
printf("\n");
return 0;
}
