#include <stdio.h>
int main() {
int a=4;
int * p;
p=&a;
printf("a=%d\n",a);
printf("*p=%d\n",*p);
return 0;
}

