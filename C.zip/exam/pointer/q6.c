#include <stdio.h>
int main() {
int a=7,b=8;
int *p; int *q;
p=&a; q=&b;
if(*p>*q){ printf("The maximum is %d\n",*p); }
else{ printf("The maximum is %d\n",*q); }
return 0;
}
