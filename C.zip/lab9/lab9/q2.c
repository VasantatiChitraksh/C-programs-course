#include<stdio.h>
int main()
{
   int n;
   printf("enter the number : ");
   scanf("%d",&n);
   int check=0;
   if (n>0 && n<100){
      switch (n/10){
         case 2:
            printf("twenty ");
            break;
         
         case 3:
            printf("thirty ");
            break;
         
         case 4:
            printf("fourty ");
            break;
         
         case 5:
            printf("fifty ");
            break;
         
         case 6:
            printf("sixty ");
            break;
         
         case 7:
            printf("seventy ");
            break;
          
         case 8:
            printf("eighty ");
            break;
         
         case 9:
            printf("ninty ");
            break;
         
         case 1:
            check=1;
            switch (n%10){
               case 1:
                  printf("eleven\n");
                  break;
               
               case 2:
                  printf("twelve\n");
                  break;
               
               case 3:
                  printf("thirteen\n");
                  break;
               
               case 4:
                  printf("fourteen\n");
                  break;
               
               case 5:
                  printf("fifteen\n");
                  break;
               
               case 6:
                  printf("sixteen\n");
                  break;
               
               case 7:
                  printf("seventeen\n");
                  break;
                  
               case 8:
                  printf("eighteen\n");
                  break;
               
               case 9:
                  printf("ninteen\n");
                  break;
               
            }
         
      }
      if (check==0){
         switch(n%10){
            case 0:
                printf("\n");
                break;

            case 1:
                printf("one\n");
                break;
            
            case 2:
                printf("two\n");
                break;
            
            case 3:
                printf("three\n");
                break;
            
            case 4:
                printf("four\n");
                break;
            
            case 5:
               printf("fife\n");
               break;
            
            case 6:
               printf("six\n");
               break;
            
            case 7:
               printf("seven\n");
               break;
             
            case 8:
               printf("eight\n");
               break;
            
            case 9:
               printf("nine\n");
               break;
            
         }
      }
   }
   else{
      printf("invalid range\n");
   }
 }
