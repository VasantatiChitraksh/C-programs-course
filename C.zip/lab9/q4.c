#include <stdio.h>
int sumOfDigits(int n){		int digit=n%10;
				int sum=0;
				if(n<10){
					return n;
					}
				sum=digit+sumOfDigits(n/10);
				return sum;
					}
int main() {
int n;
printf("Enter the number:");
scanf("%d", &n);
int x=sumOfDigits(n);
printf("The sum of digits is %d\n",x);
return 0;
}
