#include <stdio.h>
int main() {
int n,m;
printf("The no of elements in the arrays are: ");
scanf("%d", &n);
scanf("%d", &m);
int a[n],b[m];
printf("The first array in ascending order is \n");
for(int i=0;i<n;i++) {
scanf("%d", &a[i]);
}
printf("The second array in ascending order is \n");
for(int j=0;j<m;j++) {
scanf("%d", &b[j]);
}
int c[n+m],k=0,i=0,j=0;
while(i<n && j<m) {
if(a[i]>b[j]) { c[k++]=b[j++]; }
else if(a[i]<b[j]) { c[k++]=a[i++]; }
}
while(i<n) {
c[k++]=a[i++] ;
}
while(j<m) { 
c[k++]=b[j++] ;
}
printf("The mergd array is\n");
for(int l=0;l<k;l++) {
printf("%d ",c[l]);
}
printf("\n");
return 0;
}
