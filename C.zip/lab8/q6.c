#include <stdio.h>
int main() {
int n;
char r;
printf("The no of elements in the array:");
scanf("%d", &n);
int a[n];
printf("The array is:");
for(int i=0;i<n;i++) {
scanf("%d", &a[i]);
}
int k;
printf("The no of rotations are:");
scanf("%d", &k);
if(k>n){k=k%n;}
printf("Enter R for right rotation and L for left:");
scanf(" %c", &r);
if(r=='R') {
int b[n],l=0;
for(int i=n-k;i<n;i++) {
b[l++]=a[i]; }
for(int i=0;i<n-k;i++){
b[l++]=a[i]; }
for(int i=0;i<n;i++) {
printf("%d ",b[i]);
}
}
else if(r=='L') {
int b[n],l=0;
for(int i=k;i<n;i++) {
b[l++]=a[i]; }
for(int i=0;i<k;i++){
b[l++]=a[i]; }
for(int i=0;i<n;i++) {
printf("%d ",b[i]);
}
}
printf("\n");
return 0;
}

