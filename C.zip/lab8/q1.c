#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
int n;
printf("The range of integers from 1 to ");
scanf("%d", &n);
int a[10];
srand(time(0));
for(int i=0;i<10;i++) {
a[i]=rand() % n + 1;
printf("%d ",a[i]);
}
printf("\n");
int max=0,x;
for(int i=1;i<=n;i++) {
int count=0;
for(int j=0;j<10;j++) {
if(a[j]==i) {count++ ;}
}
if(max<count) { max=count;
		x=i; }
}
printf("The no %d occurs the most times it occurs %d time\n",x,max);
return 0;
}
