#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
int a[10];
srand(time(0));
for(int i=0;i<10;i++) {
a[i]=rand() % 2;
printf("%d ",a[i]);
}
printf("\n");
int max=0;
for(int i=0;i<10;) {
int count=0;
for(int j=i;j<10;j++) {
if(a[j]==1) { count++ ;
	    i++ ; }
else {    i++;
	break ; }
}
if(max<count) {
max=count ;
}
}
printf("The most conseqcutive one's are %d\n",max);
return 0;
}

