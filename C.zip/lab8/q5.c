#include <stdio.h>
int main() {
int n,m;
printf("The no of rows and columns of the matrix:");
scanf("%d", &n);
scanf("%d", &m);
int a[n][m];
printf("The matrix is \n");
for(int i=0;i<n;i++){
for(int j=0;j<m;j++){
scanf("%d", &a[i][j]);
}
}
printf("The vector matrix is \n");
int b[m];
for(int j=0;j<m;j++){
scanf("%d", &b[j]);
}
int out[n];
for(int i=0;i<n;i++){
out[i]=0;
for(int j=0;j<m;j++){
out[i]=out[i]+(a[i][j]*b[j]);
}
}
printf("The output is\n");
for(int i=0;i<n;i++){
printf("%d\n",out[i]);
}
return 0;
}
