#include <stdio.h>
int main() {
int n;
printf("The no of elements: ");
scanf("%d", &n);
int array[n];
printf("Enter the array: ");
for(int i=1; i<=n; i++) {
		scanf("%d", &array[i]);
		}
int num=array[n];
for(int i=n; i>0; i--) {
if(i>0){array[i+1]=array[i];}
}
array[1]=num;
for(int i=1; i<=n; i++) {
printf("%d ",array[i]);
}
printf("\n");
return 0;
}
