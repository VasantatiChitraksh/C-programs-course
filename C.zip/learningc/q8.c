#include <stdio.h>
int main() {
int array[6],count=0;
printf("Enter the array: ");
for(int i=0; i<6; i++) {
		scanf("%d", &array[i]);
		}
for(int i=0; i<6; i++) {
for(int j=0; j<6; j++) {
if((array[i]==array[j]) && (i<j)) { count++ ; }
}
}
printf("The no of good pairs are %d\n", count);
return 0;
}
