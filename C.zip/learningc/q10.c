#include <stdio.h>
int main() {
int array[8],count=0,sum=0;
printf("Enter the array: ");
for(int i=0; i<8; i++) {
		scanf("%d", &array[i]);
		}
for(int i=0; i<8 ; i++) {
sum += array[i];
}
for(int i=0; i<8; i++) {
if(array[i]>(2*(sum/8))) { count++ ;}
}
printf("%d\n", count);
return 0;
}
