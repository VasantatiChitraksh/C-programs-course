#include <stdio.h>
int main() {
int n;
printf("The dimensions of the 2d matrix:");
scanf("%d", &n);
int matrix[n][n];
for(int j=1; j<=n; j++) {
for(int i=1; i<=n; i++) {
scanf("%d", &matrix[i][j]);
}}
int dsum,antisum;
for(int j=1; j<=n; j++) {
for(int i=1; i<=n; i++) {
if(i==j) { dsum+=matrix[i][j]; }
}
}
for(int j=1; j<=n; j++) {
for(int i=1; i<=n; i++) {
if((i+j)==n+1) { antisum +=  matrix[i][j];  }
}
}
printf("The sum of diagonal elements is %d\n", dsum);
printf("The sum of anti diagonal elements is %d\n", antisum);
}
