#include <stdio.h>
int main() {
int n;
printf("The no of elements in the array:");
scanf("%d", &n);
int a[n];
for(int i=0;i<n;i++) {
scanf("%d", &a[i]);
}
for(int i=0;i<n;i++){
printf("%d ",a[i]);
}
printf("\n");
int count[6];
for(int i=0;i<n;i++){
count[a[i]]++;
}
for(int i=0;i<6;i++){
printf("%d ",count[i]);
}
printf("\n");
int max;
int x;
int check=0;
for(int i=0;i<6;i++){
if(count[i]>(n/2)) {
			check=1;
			max=count[i];		
			x=i;
				}
}
if(check==1){
printf("The majority in the array is %d and it occurs %d\n",x,max);
}
else if(check==0){ printf("No such majority exists\n");
}
return 0;
}
