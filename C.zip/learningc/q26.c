#include <stdio.h>
int main() {
int n;
printf("The no of elements in the array:");
scanf("%d", &n);
int array[n];
printf("The array is\n");
for(int i=0; i<n; i++) {
scanf("%d", &array[i]);
}
int k;
printf("The no of places you want to rotate:");
scanf("%d", &k);
for(i=0; i<n; i++) {
printf("hello");
printf("%d ", array[i]);
}
int array2[k],i;
for(i=n-k;i<n;i++) {
array2[i-n+k]=array[i];
}
for(i=n-k-1; i>=0; i++) {
array[i+k]=array[k];
}
for(i=0; i<k ; i++) {
array[i]=array2[i];
}
for(i=0; i<n; i++) {
printf("hello");
printf("%d ", array[i]);
}
printf("\n");
return 0;
}


