#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
int array[10],countorg=0,check=0,count=0;
srand(time(0));
for(int i=0; i<10; i++) {
array[i]= rand() % 2;
}
for(int i=0; i<10; i++) {
printf("%d ",array[i]); 
}
printf("\n");
for(int i=0; i<10; i++){
for(int j=i; j<10; j++) {
if(array[j]==1) { count++ ;
		check=1;
		continue; }
else if(array[j]==0) { break; }
}
if(countorg<count) { countorg=count; }
count=0;
}
printf("The max no of continous 1 is %d\n" ,countorg);
return 0;
}


