#include <stdio.h>
#include <stdlib.h>
int main() {
int n,sum=0;
printf("The no of elements in the array:");
scanf("%d", &n);
int array[n];
printf("The array is:");
for(int i=0; i<n; i++) {
scanf("%d", &array[i]);
}
int minsum=0;
for(int i=0; i<n ; i++){
for(int j=i; j<n ; j++){
for(int k=j; k<n ; k++){
if((array[i]!=array[j]) && (array[i]!=array[k]) && (array[j]!=array[k])){
sum+=array[i]+array[j]+array[k];}
if((minsum>sum)){minsum=sum;}
sum=0;
}
}
}
printf("YES the min sum is %d\n", minsum);
return 0;
}
