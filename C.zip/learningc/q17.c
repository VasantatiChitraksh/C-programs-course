#include <stdio.h>
int main() {
int n;
printf("The number of elements in array:");
scanf("%d", &n);
int array[n];
int i,j;
printf("The array is\n");
for(i=0;i<n;i++) {
scanf("%d", &array[i]);
}
int k,sum=0,check=0;
printf("Enter a positive number\n");
scanf("%d", &k);
for(i=0;i<n;i++){
for(j=i;j<n;j++){
sum+=array[j];
}
if(sum==k){     check=1;
		printf("There exists a sub array and index is %d to %d\n", i+1,n);
}
sum=0;
}
if(check==0){printf("-1\n");}
return 0;
}
		
