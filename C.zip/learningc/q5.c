#include <stdio.h>
int main() {
int array[10],n,count;
printf("Enter the array: ");
for(int i=0; i<10; i++) {
		scanf("%d", &array[i]);
		}
for(int i=0; i<10; i++){
		printf("%d ", array[i]);
		}
	printf("\n");
printf("Enter the number to count: ");
scanf("%d", &n);
for(int i=0; i<10; i++) { if(n==array[i]) { count++ ;} }
printf("The count of the number is %d\n", count);
return 0;
}
