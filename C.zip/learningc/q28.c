#include <stdio.h>
int main() {
int n;
printf("The no of rows of the first matrix and no of columns of second matrix:");
scanf("%d", &n);
int a[n];
int b[n];
int c[n][n];
printf("The first matrix is:\n");
for(int i=0;i<n;i++){
scanf("%d", &a[i]);
}
printf("The second matrix is:\n");
for(int i=0;i<n;i++){
scanf("%d", &b[i]);
}
for(int i=0;i<n;i++){
for(int j=0;j<n;j++){
c[i][j]=a[i]*b[j];
}}
printf("The Product of the matrix is:\n");
for(int i=0;i<n;i++){
for(int j=0;j<n;j++){
printf("%d ",c[i][j]);
}
printf("\n");
}
return 0;
}
