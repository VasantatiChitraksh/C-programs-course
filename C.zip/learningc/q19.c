#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
int n,m;
printf("The number of elements in array and the range are:");
scanf("%d", &n);
scanf("%d", &m);
int array[n];
int i,j;
srand(time(0));
printf("The array is\n");
for(i=0;i<n;i++) {
array[i] = rand() % m + 1; 
}
for(j=0;j<n;j++) {
printf("%d ",array[j]);
}
printf("\n");
int count[m],sum=0;
for(j=1;j<=m;j++){
for(i=0;i<n;i++){
if(array[i]==j) { sum++ ;}
}
count[j]=sum;
sum=0;
}
for(j=1;j<=m;j++) {
printf("%d ",count[j]);
}
printf("\n");
return 0;
}
