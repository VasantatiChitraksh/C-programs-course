#include <stdio.h>
int main() {
int a,b;
printf("Enter the no of rows and columns in the matrix:");
scanf("%d", &a);
scanf("%d", &b);
int matrix[a][b];
printf("Enter the matrix\n");
for(int i=0; i<a;i++){
for(int j=1; j<=b;j++){
scanf("%d", &matrix[i][j]);
}}
int columnsum[b],sum=0;
for(int j=1; j<=b;j++){
for(int i=0; i<a;i++){
sum += matrix[i][j];
}
columnsum[j]=sum;
sum=0;
}
for(int j=1; j<=b;j++){
printf("column[%d]=%d\n", j,columnsum[j]);
}
return 0;
}
