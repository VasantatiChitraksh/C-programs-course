#include <stdio.h>
int main(){
        int  a=10,b=6,c;
        float d;
        c=a+b;
        d=(float)a/(float)b;
        printf("The sum of the %d and %d is %d \n", a, b, c);
        printf("the quotient of the %d and %d is %f \n", a, b, d);
        return 0;
        }
