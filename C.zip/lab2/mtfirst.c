I love IIT Tirupati
I love C programming.
I love myself
