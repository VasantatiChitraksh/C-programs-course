#include <stdio.h>

int main() {
         printf("1.My JEE journey was a roller coaster of emotions.\n2.I was depressed sometimes and happy other times.\n3.I put effort only in the last 6months and managed to acheive it,\n4.My parents provided me with great emotional and moral support.\n5/Finally i have completed a stage of my life and ready to begin a new one.\n");
         return 0;
         }
