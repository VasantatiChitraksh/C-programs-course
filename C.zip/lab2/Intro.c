#include <stdio.h> 

int main() {

            printf("I love IIT Tirupati\nI love C programming.\nI love myself\n");
            
            return 0;
            }
            
