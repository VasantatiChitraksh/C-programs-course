#include <stdio.h>
int main() {
int n;
printf("The no of terms in the array:");
scanf("%d",&n);
int a[n];
printf("The array is:\n");
for(int i=0;i<n;i++) {
scanf("%d",&a[i]);
}
int check=0;
for(int i=0;i<n;i++) {
for(int j=0;j<n;j++) {
if(a[i]==a[j] && i!=j) {
check=1;
printf("The array contains duplicates\n");
return 0;
}
 }
  }
if(check==0) {
printf("No duplicates are present\n");
}
return 0;
}
