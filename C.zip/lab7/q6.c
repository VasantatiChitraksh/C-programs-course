#include <stdio.h>
int main() {
int n;
printf("The no of elements in the array:");
scanf("%d", &n);
int array[n];
printf("The array is\n");
for(int i=0; i<n; i++) {
scanf("%d", &array[i]);
}
int check=0;
int j=n-1;
for(int i=0;i<n;i++) {
if(array[i]==array[j]) {
j--;
continue;
}
else {
check=1;
break;
}
}
if(check==0) { printf("Yes is a palindrome\n"); }
else { printf("Not a palindrome\n"); }
}
