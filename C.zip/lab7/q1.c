#include <stdio.h>
int main() {
int n;
printf("Enter the no of elements in the array:");
scanf("%d",&n);
int a[n];
printf("Enter the array:\n");
for(int i=0;i<n;i++) {
scanf("%d",&a[i]);
}
int oddsum=0,evensum=0;
for(int i=0;i<n;i++) {
if(i%2==0){ evensum+=a[i]; }
else { oddsum+=a[i]; }
}
printf("Sum of odd indexed elements=%d\nSum of even indexed elements=%d\n", oddsum,evensum);
return 0;
}


