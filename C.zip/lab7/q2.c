#include <stdio.h>
int main() {
int n;
printf("The no of terms in the array:");
scanf("%d",&n);
int a[n];
int r[n];
printf("The array is:\n");
for(int i=0;i<n;i++) {
scanf("%d",&a[i]);
}
for(int i=0;i<n;i++) {
int sum=0;
for(int j=0;j<=i;j++) {
sum+=a[j];
}
r[i]=sum;
}
for(int i=0;i<n;i++) {
printf("%d ",r[i]);
}
printf("\n");
return 0;
}
