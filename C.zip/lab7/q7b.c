#include <stdio.h>
int main() {
int n;
printf("The no of elements in the array are:");
scanf("%d",&n);
int a[n],b[n];
printf("The arrays are:");
for(int i=0;i<n;i++) {
scanf("%d",&a[i]);
}
for(int i=0;i<n;i++) {
scanf("%d",&b[i]);
}
int c[n],k=0;
for(int i=0;i<n;i++) {
int check=0;
for(int j=0;j<n;j++) {
if(a[i]==b[j]) { check=1; break; }
}
if(check==1){
c[k++]=a[i];}
}
for(int i=0;i<k;i++) {
printf("%d ", c[i]);
}
printf("\n");
return 0;
} 

