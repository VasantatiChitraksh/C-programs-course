#include <stdio.h>
int main() {
int n;
printf("The no of terms in the array:");
scanf("%d",&n);
int a[n];
printf("The array is:\n");
for(int i=0;i<n;i++) {
scanf("%d",&a[i]);
}
int b[n],k=0;
for(int i=0;i<n;i++) {
if(a[i]!=0) {
b[k++]=a[i];
            }
     }
for(;k<n;k++) {
b[k]=0;
}
for(int j=0;j<n;j++) {
printf("%d ",b[j]);
}
printf("\n");
return 0;
}
