#include <stdio.h>
#include <math.h>
int main(){
double pi=0.0;
int n;
printf("Enter the no of terms in the leibniz formula to be used:");
scanf("%d",&n);
for(int i=0;i<n;i++){
double x;
x=pow(-1,i);
x=x/(2*i+1);
pi=pi+x;
}
printf("The value of pi is %lf\n",4*pi);
return 0;
}
