#include <stdio.h>
void printReverseArray(int arr[],int n){ if(n>=0){
			printf("%d ",arr[n]);
			printReverseArray(arr,n-1);
			}
			}
int main(){
int n;
printf("Enter the size of the array:");
scanf("%d",&n);
int arr[n];
for(int i=0;i<n;i++){
	scanf("%d",&arr[i]);
		}
printReverseArray(arr,n-1);
printf("\n");
return 0;
}
