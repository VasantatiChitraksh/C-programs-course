#include <stdio.h>
int noofdigits(int n){int i=1;
		if(n<10){
			return 1;
				}
		return i+noofdigits(n/10);
		}
int armstrongpower(int n,int m){ if(m==0){
				return 1;
				}
			return n*armstrongpower(n,m-1);
				}
int main() {
int n;
printf("Enter a number:");
scanf("%d",&n);
int p=noofdigits(n);
int sum=0;
int temp=n;
for(int i=0;i<p;i++){
	int x=temp%10;
	int y=armstrongpower(x,p);
	sum+=y;
	temp=temp/10;}
if(sum==n){
	printf("It is an armstrong number.\n");
		}
else{
	printf("It is not an armstrong number.\n");
		}
}

