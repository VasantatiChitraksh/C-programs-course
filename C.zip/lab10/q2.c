#include <stdio.h>
int main(){
int a,b,c;
int *p;
int *q;
int *r;
p=&a; q=&b; r=&c;
printf("The three integer are:");
scanf("%d",p);
scanf("%d",q);
scanf("%d",r);
printf("THE ADDRESS OF EACH VARIABLE ARE:\na=%p\nb=%p\nc=%p\n",p,q,r);
printf("THE VALUES ARE:\na=%d\nb=%d\nc=%d\n",*p,*q,*r);
return 0;
}
