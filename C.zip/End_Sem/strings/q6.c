#include <stdio.h>
#include <string.h>
void reverse(char *s){
	static int i=0,n,temp;
	n=strlen(s);
	if(i<n/2){
		temp=s[i];
		s[i]=s[n-i-1];
		s[n-i-1]=temp;
		i++;
		reverse(s);
		}
			}
int main(){
char s[100];
printf("Input:");
scanf("%s", s);
reverse(s);
printf("Output:%s\n",s);
return 0;
}




		
