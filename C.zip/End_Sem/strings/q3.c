#include <stdio.h>
#include <string.h>
int main(){
char s[100];
char l[100];
printf("Input1:");
scanf("%s", s);
printf("Input2:");
scanf("%s", l);
if(strlen(s)!=strlen(l)){
	printf("Not an anagram\n");
	return 0;
	}
	int check=0;
for(int i=0;i<strlen(s);i++){
for(int j=0;j<strlen(l);j++){
if(s[i]==l[j]){
	check=1;
	break;
	}
}
if(check==0){
	printf("Not an Anagram\n");
	return 0;
		}
check=0;
}
if(check==1){
	printf("Yes Annagram\n");
	}
return 0;
}


