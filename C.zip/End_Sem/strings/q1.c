#include <stdio.h>
#include <string.h>
int main(){
char s[10];
scanf("%s", s);
printf("The string is %s\n", s);
int count1=0,count2=0,count3=0;
for(int i=0;i<strlen(s);i++){
	if(s[i]<='Z' && s[i]>='A'){
		count1++;
			}
	if(s[i]<='z' && s[i]>='a'){
		count2++;
			}
	if(s[i]>='0' && s[i]<='9'){
		count3++;
		}
			}
printf("Uppercase:%d\nLowercase:%d\nDigits:%d\nTotal Length:%d\n",
count1,count2,count3,count1+count2+count3);
return 0;
}
	

