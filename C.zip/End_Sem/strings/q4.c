#include <stdio.h>
#include <string.h>
int main(){
char s[100];
int k;
printf("Input:");
scanf("%s", s);
printf("Rotations:");
scanf("%d",&k);
int n=strlen(s);
char r;
printf("Side:");
scanf(" %c",&r);
	if(r=='R'){
	for(int i=0;i<k;i++){
	int temp=s[n-1];
	for(int j=n-1;j>0;j--){
	s[j]=s[j-1];
	}
	s[0]=temp;
	}
		}
		
	if(r=='L'){
	for(int i=0;i<k;i++){
	int temp=s[0];
	for(int j=0;j<n-1;j++){
	s[j]=s[j+1];
	}
	s[n-1]=temp;
	}
		}
	
printf("Output:%s\n", s);
return 0;
}

