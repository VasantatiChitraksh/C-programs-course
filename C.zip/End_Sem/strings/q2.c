#include <stdio.h>
#include <string.h>
int main(){
char s[6];
printf("Input:");
scanf("%s", s);
int check=0;
int n=strlen(s);
//printf("%d",n);
for(int i=0;i<=(n/2);i++){
	if(s[i]==s[n-i-1]){
		continue;
		}
	else{
		check=1;
		break;
		}
	}
if(check==0){
	printf("Palindrome\n");
	}
if(check==1){
	printf("Not Palindrome\n");
	}
return 0;
}
