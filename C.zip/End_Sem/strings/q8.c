#include <stdio.h>
#include <string.h>
void reverse(char *s,int m){
	int n;
	n=m;
	int i=0;
	int count=0;
	while(s[n-i-1]!='\0'){
		count++;
		i++;
		}
	for(int j=n-count;j<n;j++){
	printf("%c",s[j]); 	
			}
	n=n-count-1;
	if(n>=0){
	reverse(s,n);
		}
			}
int main(){
char s[100];
printf("Input:");
scanf("%[^\n]s", s);
int m=strlen(s);
reverse(s,m);
//printf("Output:%s\n",s);
return 0;
}




		
