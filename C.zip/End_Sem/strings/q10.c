#include <string.h>
#include <stdio.h>
int main(){
char s1[100];
char s2[10];
char s3[10];
int n,m,p;
scanf("%s", s1);
scanf("%s", s2);
scanf("%s", s3);
n=strlen(s1);
m=strlen(s2);
p=strlen(s3);
for(int i=0;i<n-m;i++){
int j;
for(int j=0;j<m;j++){
if(s1[i+j]=s2[j]){
	break;
	}
		}
if(j==m){ if(p==m){
	for(int l=0;l<p;l++){
	s1[i+l]=s3[l];
	break;
	}
	}
	else if(p>m){
	int l;
	for(l=0;l<m;l++){
	s1[i+l]=s3[l];
	}
	while(l<p){
	int temp=s1[i+l];
	s1[i+l]=s3[l];
	s1[i+l+1]=temp;
	l++;
	}
	while(l<n){
	s1[i+l+1]=s1[i+l];
	l++;
	}
	 	}
	 		}
	 		 	}
printf("%s\n", s1);
return 0;
	 		 		}
