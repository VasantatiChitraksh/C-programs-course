#include <stdio.h>
#include <string.h>

void replaceSubstring(char *S1, char *S2, char *S3) {
    int len1 = strlen(S1);
    int len2 = strlen(S2);
    int len3 = strlen(S3);

    for (int i = 0; i <= len1 - len2; i++) {
        int j;

        for (j = 0; j < len2; j++) {
            if (S1[i + j] != S2[j]) {
                break;
            }
        }

        if (j == len2) {  // If S2 is found in S1
            for (int k = i; k < i + len2; k++) {
                S1[k] = '\0';  // Null out characters to remove S2
            }

            // Copy S3 in place of S2
            for (int k = len1; k >= i + len2; k--) {
                S1[k + len3 - len2] = S1[k];
            }

            // Copy S3 into the empty space
            for (int k = 0; k < len3; k++) {
                S1[i + k] = S3[k];
            }
        }
        continue;
    }
}

int main() {
    char S1[100];
    char S2[10];
    char S3[10];

    printf("Enter the main string (S1): ");
    scanf("%s", S1);

    printf("Enter the substring to replace (S2): ");
    scanf("%s", S2);

    printf("Enter the replacement string (S3): ");
    scanf("%s", S3);

    replaceSubstring(S1, S2, S3);

    printf("Replaced string: %s\n", S1);

    return 0;
}

