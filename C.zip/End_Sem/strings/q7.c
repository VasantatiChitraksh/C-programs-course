#include <stdio.h>
#include <string.h>
int slen(char  *s){
	static int i,count;
	if(s[i]!='\0'){
		count++;
		i++;
		slen(s);
		}
	return count;
	}
int main(){
char s[100];
scanf("%s", s);
int m=slen(s);
printf("The length of the string is: %d\n",m);
return 0;
}

	
