#include <stdio.h>
int main(){
	int a=12,b=4,c;
	c=a+b*3;
	printf("%d\n",c);
	c=a/4+b/4;
	printf("%d\n",c);
	c=a*2+b;
	printf("%d\n",c);
	c=(a+b)*2;
	printf("%d\n",c);
	c=a-b*3;
	printf("%d\n",c);
	return 0;
	}
