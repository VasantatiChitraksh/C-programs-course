#include <stdio.h>
int myPrePlusPlus(int *p){
		++(*p);
		return *p;
		}
int myPostPlusPlus(int *p){
		(*p)++;
		return (*p)-1;
			}
int myPreMinusMinus(int *p){
		--(*p);
		return *p;
		}
int myPostMinusMinus(int *p){
		(*p)--;
		return (*p)+1;
		}
int main(){
int a;
printf("The numbers is:");
scanf("%d",&a);
int c=myPrePlusPlus(&a);
printf("The preincremented value and value of num %d %d\n",c,a);
c=myPostPlusPlus(&a);
printf("The postincremented value and value of num %d %d\n",c,a);
a=c;
int d=myPreMinusMinus(&a);
printf("The predecremented value %d and value of num %d\n",d,a);
d=myPostMinusMinus(&a);
printf("The postdecremented value %d and value of num %d\n",d,a);
return 0;
}



		
