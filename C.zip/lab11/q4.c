#include <stdio.h>
void swap(int *p,int *q){
	int temp=*p;
	*p=*q;
	*q=temp;
	}
int main(){
int n;
printf("The size of the array is:");
scanf("%d",&n);
int a[n];
printf("The array is:");
for(int i=0;i<n;i++){
	scanf("%d",&a[i]);
		}
for(int j=0;j<n-1;j++) {
int check=0;
for(int i=0;i<n-1-j;i++){
	if(a[i]>a[i+1]){
		check=1;
		swap(&a[i],&a[i+1]);
		}
	}
if(check==0){ break;}
	}
printf("The sorted array is:");
for(int i=n-1;i>=0;i--){
	printf("%d ",a[i]);
		}
		printf("\n");
return 0;
}
